import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Config:
    bot_token: str
    openai_api_key: str
    pro_price_stars: int
    free_limit: int
    pro_limit: int
    ai_background: bool
    admin_ids: tuple[int, ...]

def load_config() -> Config:
    token = os.getenv("BOT_TOKEN", "").strip()
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not token:
        raise RuntimeError("BOT_TOKEN is missing")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is missing")
    admins = tuple(int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit())
    return Config(
        token, key,
        int(os.getenv("PRO_PRICE_STARS", "499")),
        int(os.getenv("FREE_LIMIT", "3")),
        int(os.getenv("PRO_LIMIT", "100")),
        os.getenv("AI_BACKGROUND", "0") == "1",
        admins
    )
