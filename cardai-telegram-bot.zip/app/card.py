from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
import textwrap

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

def f(n, b=False):
    try:
        return ImageFont.truetype(BOLD if b else FONT, n)
    except Exception:
        return ImageFont.load_default()

def make_card(photo, out, product, style, size, bg=None):
    dims = {"1:1":(1024,1024),"4:5":(1024,1280),"3:4":(1024,1365),"9:16":(1024,1536)}
    W, H = dims.get(size, (1024,1280))
    if bg and Path(bg).exists():
        canvas = Image.open(bg).convert("RGB").resize((W,H))
    else:
        canvas = Image.new("RGB", (W,H), (246,242,250))
    canvas = canvas.convert("RGBA")
    panel = Image.new("RGBA", (W,H), (0,0,0,0))
    pd = ImageDraw.Draw(panel)
    pd.rounded_rectangle((32,32,W-32,H-32), radius=34, fill=(255,255,255,220))
    canvas = Image.alpha_composite(canvas, panel)

    im = Image.open(photo).convert("RGBA")
    im.thumbnail((int(W*.80), int(H*.57)), Image.Resampling.LANCZOS)
    sh = Image.new("RGBA", im.size, (0,0,0,0))
    sh.putalpha(im.getchannel("A").filter(ImageFilter.GaussianBlur(20)))
    x = (W-im.width)//2
    y = int(H*.25)
    canvas.alpha_composite(sh, (x+12,y+18))
    canvas.alpha_composite(im, (x,y))

    d = ImageDraw.Draw(canvas)
    title = str(product.get("headline") or product.get("product_name") or "Товар")
    sub = str(product.get("subtitle") or "")
    benefits = product.get("benefits") or []
    d.text((68,62), title[:50], font=f(50,True), fill=(57,25,78))
    d.multiline_text((70,132), textwrap.fill(sub,34), font=f(26), fill=(75,68,82), spacing=6)
    yy = int(H*.85)
    for i,b in enumerate(benefits[:3]):
        d.rounded_rectangle((62,yy+i*60,W-62,yy+46+i*60), radius=16, fill=(91,48,123,235))
        d.text((84,yy+8+i*60), "✓ "+str(b)[:42], font=f(21,True), fill="white")
    d.text((68,H-48), "CardAI", font=f(18,True), fill=(110,100,120))
    canvas.convert("RGB").save(out, "PNG", optimize=True)
