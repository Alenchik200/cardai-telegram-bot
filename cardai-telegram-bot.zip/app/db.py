import aiosqlite
from datetime import datetime, timezone

DB_PATH = "data/cardai.sqlite3"

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT, plan TEXT NOT NULL DEFAULT "free", used INTEGER NOT NULL DEFAULT 0, subscription_until TEXT, created_at TEXT NOT NULL)')
        await db.execute('CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, payload TEXT, amount INTEGER, currency TEXT, charge_id TEXT, created_at TEXT NOT NULL)')
        await db.commit()

async def ensure_user(uid, username):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'INSERT OR IGNORE INTO users(user_id,username,created_at) VALUES(?,?,?)',
            (uid, username, datetime.now(timezone.utc).isoformat())
        )
        await db.execute('UPDATE users SET username=? WHERE user_id=?', (username, uid))
        await db.commit()

async def get_user(uid):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        return await (await db.execute('SELECT * FROM users WHERE user_id=?', (uid,))).fetchone()

async def increment_used(uid):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('UPDATE users SET used=used+1 WHERE user_id=?', (uid,))
        await db.commit()

async def activate_pro(uid, until):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('UPDATE users SET plan="pro",subscription_until=? WHERE user_id=?', (until, uid))
        await db.commit()

async def save_payment(uid, payload, amount, currency, charge):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'INSERT INTO payments(user_id,payload,amount,currency,charge_id,created_at) VALUES(?,?,?,?,?,?)',
            (uid, payload, amount, currency, charge, datetime.now(timezone.utc).isoformat())
        )
        await db.commit()

async def stats():
    async with aiosqlite.connect(DB_PATH) as db:
        a = await (await db.execute('SELECT COUNT(*) FROM users')).fetchone()
        b = await (await db.execute('SELECT COUNT(*) FROM users WHERE plan="pro"')).fetchone()
        c = await (await db.execute('SELECT COALESCE(SUM(used),0) FROM users')).fetchone()
        d = await (await db.execute('SELECT COALESCE(SUM(amount),0) FROM payments')).fetchone()
        return a[0], b[0], c[0], d[0]
