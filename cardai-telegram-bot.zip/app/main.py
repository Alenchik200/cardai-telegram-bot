import asyncio
from pathlib import Path
from datetime import datetime, timedelta, timezone
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, LabeledPrice, PreCheckoutQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from openai import AsyncOpenAI

from .config import load_config
from .db import init_db, ensure_user, get_user, increment_used, activate_pro, save_payment, stats
from .ai import analyze_product, generate_background
from .card import make_card

cfg = load_config()
bot = Bot(cfg.bot_token)
dp = Dispatcher()
ai = AsyncOpenAI(api_key=cfg.openai_api_key)

class CardState(StatesGroup):
    photo = State()
    style = State()
    size = State()

STYLES = ["Premium","Marketplace","Minimal","Bright","Food"]
SIZES = ["1:1","4:5","3:4","9:16"]

def menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Создать карточку", callback_data="make")],
        [InlineKeyboardButton(text="PRO — 100/месяц", callback_data="pro")],
        [InlineKeyboardButton(text="Мой тариф", callback_data="me")]
    ])

def styles():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=x, callback_data=f"style:{x}") for x in STYLES[:2]],
        [InlineKeyboardButton(text=x, callback_data=f"style:{x}") for x in STYLES[2:4]],
        [InlineKeyboardButton(text=STYLES[4], callback_data=f"style:{STYLES[4]}")]
    ])

def sizes():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=x, callback_data=f"size:{x}") for x in SIZES[:2]],
        [InlineKeyboardButton(text=x, callback_data=f"size:{x}") for x in SIZES[2:]]
    ])

async def allowed(uid):
    u = await get_user(uid)
    return not u or u["used"] < (cfg.pro_limit if u["plan"]=="pro" else cfg.free_limit)

@dp.message(Command("start"))
async def start(m: Message, state: FSMContext):
    await state.clear()
    await ensure_user(m.from_user.id, m.from_user.username)
    await m.answer("<b>CardAI</b>\n\nФото товара → готовая продающая карточка.\nAI распознаёт товар и оформляет дизайн.",
                   reply_markup=menu(), parse_mode="HTML")

@dp.callback_query(F.data=="make")
async def make(c: CallbackQuery, state: FSMContext):
    await c.answer()
    if not await allowed(c.from_user.id):
        return await c.message.answer("Лимит закончился. Оформи PRO:", reply_markup=menu())
    await state.set_state(CardState.photo)
    await c.message.answer("Отправь фотографию товара.")

@dp.message(CardState.photo, F.photo)
async def photo(m: Message, state: FSMContext):
    await state.update_data(file_id=m.photo[-1].file_id)
    await state.set_state(CardState.style)
    await m.answer("Выбери стиль:", reply_markup=styles())

@dp.callback_query(CardState.style, F.data.startswith("style:"))
async def style(c: CallbackQuery, state: FSMContext):
    await c.answer()
    await state.update_data(style=c.data.split(":",1)[1])
    await state.set_state(CardState.size)
    await c.message.answer("Выбери формат:", reply_markup=sizes())

@dp.callback_query(CardState.size, F.data.startswith("size:"))
async def size(c: CallbackQuery, state: FSMContext):
    await c.answer()
    data = await state.get_data()
    await state.clear()
    size = c.data.split(":",1)[1]
    status = await c.message.answer("AI анализирует товар и создаёт карточку…")
    ip = bp = None
    try:
        tg = await bot.get_file(data["file_id"])
        ip = Path("output") / f"{c.from_user.id}_input.jpg"
        await bot.download_file(tg.file_path, ip)
        product = await analyze_product(ai, str(ip))
        if cfg.ai_background:
            bp = Path("output") / f"{c.from_user.id}_bg.png"
            bp.write_bytes(await generate_background(ai, product, data["style"], size))
        out = Path("output") / f"{c.from_user.id}_{int(datetime.now().timestamp())}.png"
        make_card(str(ip), str(out), product, data["style"], size, str(bp) if bp else None)
        await increment_used(c.from_user.id)
        await c.message.answer_photo(out.open("rb"),
            caption=f"<b>Готово!</b>\n\n{product.get('product_name','Товар')}\nСтиль: {data['style']} · {size}",
            parse_mode="HTML", reply_markup=menu())
    except Exception as e:
        print("ERROR:", repr(e))
        await c.message.answer("Не получилось создать карточку. Попробуй ещё раз.")
    finally:
        if ip: ip.unlink(missing_ok=True)
        if bp: bp.unlink(missing_ok=True)
        await status.delete()

@dp.callback_query(F.data=="pro")
async def pro(c: CallbackQuery):
    await c.answer()
    await bot.send_invoice(
        chat_id=c.from_user.id, title="CardAI PRO",
        description="100 карточек в месяц, все стили и HD.",
        payload="cardai_pro_monthly", currency="XTR",
        prices=[LabeledPrice(label="CardAI PRO", amount=cfg.pro_price_stars)],
        subscription_period=2592000
    )

@dp.pre_checkout_query()
async def checkout(q: PreCheckoutQuery):
    await q.answer(ok=True)

@dp.message(F.successful_payment)
async def paid(m: Message):
    p = m.successful_payment
    until = datetime.now(timezone.utc) + timedelta(days=30)
    await activate_pro(m.from_user.id, until.isoformat())
    await save_payment(m.from_user.id, p.invoice_payload, p.total_amount, p.currency, p.telegram_payment_charge_id)
    await m.answer("<b>PRO активирован!</b>\n100 карточек в месяц.", parse_mode="HTML", reply_markup=menu())

@dp.callback_query(F.data=="me")
async def me(c: CallbackQuery):
    await c.answer()
    u = await get_user(c.from_user.id)
    if not u:
        await ensure_user(c.from_user.id, c.from_user.username)
        u = await get_user(c.from_user.id)
    limit = cfg.pro_limit if u["plan"]=="pro" else cfg.free_limit
    await c.message.answer(f"<b>Тариф:</b> {u['plan'].upper()}\nИспользовано: {u['used']} / {limit}",
                           parse_mode="HTML", reply_markup=menu())

@dp.message(Command("paysupport"))
async def paysupport(m: Message):
    await m.answer("По вопросам оплаты: напиши администратору бота.")

@dp.message(Command("stats"))
async def admin_stats(m: Message):
    if m.from_user.id not in cfg.admin_ids:
        return
    users, pro, cards, revenue = await stats()
    await m.answer(f"Пользователи: {users}\nPRO: {pro}\nКарточек: {cards}\nStars: {revenue}")

async def main():
    await init_db()
    print("CardAI started")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
