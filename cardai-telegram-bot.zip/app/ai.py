import base64, json
from pathlib import Path
from openai import AsyncOpenAI

PROMPT = '''Ты AI-редактор карточек товара. Проанализируй изображение.
Не выдумывай характеристики. Верни только JSON с полями:
product_name, headline, subtitle, benefits (3 пункта), category.'''

async def analyze_product(client: AsyncOpenAI, path: str):
    data = base64.b64encode(Path(path).read_bytes()).decode()
    r = await client.responses.create(
        model="gpt-5.6-luna",
        input=[{"role":"user","content":[
            {"type":"input_text","text":PROMPT},
            {"type":"input_image","image_url":f"data:image/jpeg;base64,{data}"}
        ]}]
    )
    raw = r.output_text.strip().replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(raw)
    except Exception:
        return {
            "product_name": "Товар",
            "headline": "Качественный товар",
            "subtitle": "Готовая карточка",
            "benefits": ["Удобный формат", "Яркий дизайн", "Для магазина"],
            "category": "Товар"
        }

async def generate_background(client, product, style, size):
    sizes = {"1:1":"1024x1024","4:5":"1024x1280","3:4":"1024x1365","9:16":"1024x1536"}
    prompt = f'''Premium commercial marketplace background. Category: {product.get("category","product")}.
Style: {style}. Clean studio advertising scene, empty area for real product photo,
safe area for typography, no text, no logos, no watermark. Aspect ratio {size}.'''
    r = await client.images.generate(
        model="gpt-image-2",
        prompt=prompt,
        size=sizes.get(size, "1024x1280"),
        quality="low",
        output_format="png",
        n=1
    )
    return base64.b64decode(r.data[0].b64_json)
