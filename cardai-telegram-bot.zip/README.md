# CardAI — Telegram AI-бот
Фото товара → AI-анализ → готовая PNG-карточка.

## Запуск
1. Создайте бота через @BotFather.
2. Создайте OpenAI API key.
3. На Railway добавьте переменные BOT_TOKEN и OPENAI_API_KEY.
4. Deploy.

Локально:
pip install -r requirements.txt
python -m app.main
